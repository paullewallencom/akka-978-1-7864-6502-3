#!/bin/bash
sbt clean docker:publishLocal